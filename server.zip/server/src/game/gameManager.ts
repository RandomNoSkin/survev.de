import type { WebSocket } from "uWebSockets.js";
import { randomUUID } from "crypto";
import NanoTimer from "nanotimer";
import { platform } from "os";
import type { MapDefs } from "../../../shared/defs/mapDefs";
import * as net from "../../../shared/net/net";
import { Config } from "../config";
import type {
    AdminCmdAction,
    DashboardPlayer,
    FindGamePrivateBody,
    FindPrivateLobbyGameBody,
    GameData,
    GameSocketData,
    ServerGameConfig,
} from "../utils/types";
import { Game } from "./game";

export abstract class GameManager {
    abstract sockets: Map<string, WebSocket<GameSocketData>>;

    abstract getPlayerCount(): number;

    abstract getById(id: string): GameData | undefined;

    abstract findGame(body: FindGamePrivateBody): Promise<string>;

    /** Spins up a fresh isolated game from a private lobby and registers each team's players as its own join group. */
    abstract createPrivateGame(body: FindPrivateLobbyGameBody): Promise<string>;

    abstract findGameById(gameId: string, playerData: any[], autoFill: boolean): Promise<string>;
    abstract getGames(): Promise<GameData[]>;

    /** Returns true if this IP recently used a join token with a linked account (skip proxy check). */
    abstract ipHasAccount(ip: string): boolean;

    /** Returns live player data for a running game (for the moderation dashboard). */
    abstract getGamePlayers(gameId: string): Promise<DashboardPlayer[]>;

    /** Returns the recent kill-feed buffer for a running game (for the moderation dashboard). */
    abstract getGameFeed(gameId: string): Promise<import("../utils/types").KillFeedEntry[]>;

    /** Sends an admin command to a running game (fire-and-forget). */
    abstract sendAdminCmd(gameId: string, cmd: AdminCmdAction): void;

    /** Sets verified-only mode on all running games and all future games. */
    abstract setServerVerified(state: boolean): void;

    abstract onOpen(socketId: string, socket: WebSocket<GameSocketData>): void;

    abstract onMsg(socketId: string, msg: ArrayBuffer): void;

    abstract onClose(socketId: string): void;
}

/**
 * Game manager that runs all game in the same process
 * Used for dev server
 */
export class SingleThreadGameManager implements GameManager {
    readonly sockets = new Map<string, WebSocket<GameSocketData>>();

    readonly gamesById = new Map<string, Game>();
    readonly games: Game[] = [];

    serverVerifiedOnly = false;

    constructor() {
        // setInterval on windows sucks
        // and doesn't give accurate timings
        if (platform() === "win32") {
            new NanoTimer().setInterval(
                () => {
                    this.update();
                },
                "",
                `${1000 / Config.gameTps}m`,
            );

            new NanoTimer().setInterval(
                () => {
                    this.netSync();
                },
                "",
                `${1000 / Config.netSyncTps}m`,
            );
        } else {
            setInterval(() => {
                this.update();
            }, 1000 / Config.gameTps);

            setInterval(() => {
                this.netSync();
            }, 1000 / Config.netSyncTps);
        }
    }

    update(): void {
        for (let i = 0; i < this.games.length; i++) {
            const game = this.games[i];
            if (game.stopped) {
                this.games.splice(i, 1);
                i--;
                this.gamesById.delete(game.id);
                continue;
            }
            game.update();
        }
    }

    netSync(): void {
        for (let i = 0; i < this.games.length; i++) {
            this.games[i].netSync();
        }
    }

    getPlayerCount(): number {
        return this.games.reduce((a, b) => {
            return (
                a +
                (b ? b.playerBarn.livingPlayers.filter((p) => !p.disconnected).length : 0)
            );
        }, 0);
    }

    async newGame(config: ServerGameConfig): Promise<Game> {
        const id = randomUUID();
        const game = new Game(
            id,
            config,
            (id, data) => {
                this.sockets.get(id)?.send(data, true, false);
            },
            (id, reason) => {
                const socket = this.sockets.get(id);
                if (socket && !socket.getUserData().closed) {
                    if (reason) {
                        const disconnectMsg = new net.DisconnectMsg();
                        disconnectMsg.reason = reason;
                        const stream = new net.MsgStream(new ArrayBuffer(128));
                        stream.serializeMsg(net.MsgType.Disconnect, disconnectMsg);
                        socket.send(stream.getBuffer(), true, false);
                    }
                    socket.close();
                }
            },
        );
        await game.init();
        game.verifiedOnly = this.serverVerifiedOnly;
        this.games.push(game);
        this.gamesById.set(id, game);
        return game;
    }

    getById(id: string): GameData | undefined {
        return this.gamesById.get(id);
    }

    async findGame(body: FindGamePrivateBody): Promise<string> {
        let game = this.games
            .filter((game) => {
                return (
                    game.canJoin &&
                    game.teamMode === body.teamMode &&
                    game.mapName === body.mapName
                );
            })
            .sort((a, b) => {
                return a.startedTime - b.startedTime;
            })[0];

        if (!game) {
            game = await this.newGame({
                teamMode: body.teamMode,
                mapName: body.mapName as keyof typeof MapDefs,
            });
        }

        if (game.verifiedOnly && body.playerData.some((p) => !p.userId)) {
            return "player_not_verified";
        }

        game.addJoinTokens(body.playerData, body.autoFill);

        return game.id;
    }

    async createPrivateGame(body: FindPrivateLobbyGameBody): Promise<string> {
        const game = await this.newGame({
            teamMode: body.teamMode,
            mapName: body.mapName as keyof typeof MapDefs,
            isPrivate: true,
            arenaRoles: body.arenaRoles,
            advancedSettings: body.advancedSettings,
            customLoadout: body.customLoadout,
            customLoadoutEnabled: body.customLoadoutEnabled,
            publicSpectating: body.publicSpectating,
        });

        game.addGroupedJoinTokens(body.teams);
        if (body.spectators?.length) {
            game.addJoinTokensAsSpectator(body.spectators, false);
        }
        return game.id;
    }

    async findGameById(gameId: string, playerData: any[], autoFill: false): Promise<string> {
        let game = this.gamesById.get(gameId);

        if (!game || game.aliveCount < 0) {
            return "";
        }

        game.addJoinTokensAsSpectator(playerData, autoFill);

        return game.id;
    }

    async getGames(): Promise<GameData[]> {
        return this.games.map((game) => game);
    }

    ipHasAccount(_ip: string): boolean {
        // SingleThread mode is dev-only; skip the check there
        return false;
    }

    async getGamePlayers(gameId: string): Promise<DashboardPlayer[]> {
        return this.gamesById.get(gameId)?.getPlayerDataForDashboard() ?? [];
    }

    async getGameFeed(gameId: string): Promise<import("../utils/types").KillFeedEntry[]> {
        return this.gamesById.get(gameId)?.recentKills ?? [];
    }

    sendAdminCmd(gameId: string, cmd: AdminCmdAction): void {
        this.gamesById.get(gameId)?.executeAdminCmd(cmd);
    }

    setServerVerified(state: boolean): void {
        this.serverVerifiedOnly = state;
        const cmd: AdminCmdAction = { action: state ? "verify" : "unverify" };
        for (const game of this.games) {
            game.executeAdminCmd(cmd);
        }
    }

    onOpen(socketId: string, socket: WebSocket<GameSocketData>): void {
        const data = socket.getUserData();
        const game = this.gamesById.get(data.gameId);
        if (game === undefined) {
            console.log(`Game ${data.gameId} not found, closing socket.`);
            socket.close();
            return;
        }
        this.sockets.set(socketId, socket);
    }

    onMsg(socketId: string, msg: ArrayBuffer): void {
        const data = this.sockets.get(socketId)?.getUserData();
        if (!data) return;
        this.gamesById.get(data.gameId)?.handleMsg(msg, socketId, data.ip);
    }

    onClose(socketId: string) {
        const data = this.sockets.get(socketId)?.getUserData();
        if (!data) return;
        this.gamesById.get(data.gameId)?.handleSocketClose(socketId);
        this.sockets.delete(socketId);
    }
}
