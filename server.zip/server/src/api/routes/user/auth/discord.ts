import { Discord, generateCodeVerifier, generateState } from "arctic";
import { Hono } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import { Config } from "../../../../config";
import { cookieDomain, getRedirectUri, handleAuthUser } from "./authUtils";

export const discord = new Discord(
    Config.secrets.DISCORD_CLIENT_ID!,
    Config.secrets.DISCORD_SECRET_ID!,
    getRedirectUri("discord"),
);

const stateCookieName = "discord_oauth_state";
const codeVerifierCookieName = "discord_code_verifier";

export const DiscordRouter = new Hono();

DiscordRouter.use(async (c, next) => {
    if (!(Config.secrets.DISCORD_CLIENT_ID && Config.secrets.DISCORD_SECRET_ID)) {
        return c.text("Discord login is not supported", 500);
    }
    await next();
});

/** Cookie that carries the post-login redirect target (e.g. "/moderation"). */
const redirectCookieName = "oauth_redirect";

DiscordRouter.get("/", (c) => {
    const state = generateState();
    const codeVerifier = generateCodeVerifier();

    const url = discord.createAuthorizationURL(state, codeVerifier, [
        "identify",
        "email",
    ]);

    setCookie(c, stateCookieName, state, {
        path: "/",
        //secure: process.env.NODE_ENV === "production",
        secure: false,
        httpOnly: true,
        maxAge: 60 * 10,
        sameSite: "Lax",
        domain: cookieDomain,
    });

    setCookie(c, codeVerifierCookieName, codeVerifier, {
        //secure: process.env.NODE_ENV === "production",
        secure: false,
        path: "/",
        httpOnly: false,
        maxAge: 60 * 10,
        sameSite: "Lax",
        domain: cookieDomain,
    });

    // Persist the optional redirect target so the callback can use it
    const redirectTarget = c.req.query("redirect");
    if (redirectTarget) {
        setCookie(c, redirectCookieName, redirectTarget, {
            path: "/",
            secure: false,
            httpOnly: true,
            maxAge: 60 * 10,
            sameSite: "Lax",
            domain: cookieDomain,
        });
    }

    url.searchParams.append("prompt", "none");
    return c.redirect(url);
});

DiscordRouter.get("/callback", async (c) => {
    console.log("Discord callback");
    const code = c.req.query("code")?.toString() ?? null;
    const state = c.req.query("state")?.toString() ?? null;
    const storedState = getCookie(c)[stateCookieName] ?? null;
    const storedCodeVerifier = getCookie(c)[codeVerifierCookieName] ?? null;
    console.log("code:", code);
    console.log("state:", state);
    console.log("storedState:", storedState);
    console.log("storedCodeVerifier:", storedCodeVerifier);

    if (!code || !state || !storedCodeVerifier || !storedState || state !== storedState) {
        return c.json({}, 400);
    }

    const tokens = await discord.validateAuthorizationCode(code, storedCodeVerifier);

    const discordUserResponse = await fetch("https://discord.com/api/users/@me", {
        headers: {
            Authorization: `Bearer ${tokens.accessToken()}`,
        },
    });

    const resData = (await discordUserResponse.json()) as {
        id: string;
        verified: boolean;
    };

    if (!resData.verified) {
        return c.json({ error: "verified_email_required" }, 400);
    }

    await handleAuthUser(c, "discord", resData.id);

    // Redirect to the stored target (e.g. /moderation) or fall back to the default path
    const redirectTarget = getCookie(c)[redirectCookieName];
    return c.redirect(redirectTarget ?? Config.oauthBasePath);
});
